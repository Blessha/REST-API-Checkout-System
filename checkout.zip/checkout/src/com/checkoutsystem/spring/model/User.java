package com.checkoutsystem.spring.model;

public class User {
	private int quanOne;
	private int quanTwo;
	private int quanThree;
	public int getQuanOne() {
		return quanOne;
	}
	public void setQuanOne(int quanOne) {
		this.quanOne = quanOne;
	}
	public int getQuanTwo() {
		return quanTwo;
	}
	public void setQuanTwo(int quanTwo) {
		this.quanTwo = quanTwo;
	}
	public int getQuanThree() {
		return quanThree;
	}
	public void setQuanThree(int quanThree) {
		this.quanThree = quanThree;
	}

	
}
